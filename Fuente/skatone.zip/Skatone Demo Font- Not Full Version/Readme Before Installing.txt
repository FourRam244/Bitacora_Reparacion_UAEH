Hello,

By installing or using this font, you are agree to the Product Usage Agreement:
- This DEMO FONT (NOT FULL VERSION) is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

- Please visit this link, if you need a commercial license (FULL VERSION) as below:
 
  Best Price: https://typebae.gumroad.com/l/skatone

Pilihan lisensi komoersial
- Webfont Extended License
- Logo License
- Extended License (includes: E-book/Digital Publishing, Digital Ads For Social Media Commercial, End Product For Commercial: Prints/Sales/Pcs/Static digital images.
- App/Game License
- Server License
- Broadcast License
- Corporate License

Please send a short message with your question
typebaecreative@gmail.com

WARNING!!!
If this free font (personal Use) is used for commercial purposes, a fine of $5000 will be imposed

Greetings,
Typebae Foundry